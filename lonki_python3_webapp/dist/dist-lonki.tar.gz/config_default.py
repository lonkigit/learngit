#!/usr/bin/env python3
# -*- coding: utf-8 -*-

__author__ = 'lonki'

configs = {
    'debug':True,
    'db':{
        'host':'127.0.0.1',
        'port':3306,
        'user':'root',
        'password':'zhujie8721*',
        'db':'project'
    },
    'session':{
        'secret':'lonki'
    }
}